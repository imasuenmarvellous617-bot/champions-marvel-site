# Champions Marvel (Lite)

This is a lightweight, mobile-friendly version of the Champions Marvel web app.

- Circular rotating menu with social media links
- Background music (shortened for fast load)
- Responsive design

## Deployment

### Netlify (Easy Method)
1. Go to https://app.netlify.com/
2. Create an account (email or GitHub).
3. Add new site → Deploy manually.
4. Drag & drop the entire `champions-marvel-lite/` folder.
5. Done! Your site will be live instantly.

### GitHub Pages (Alternative)
1. Create a repo named `champions-marvel`.
2. Upload all files from this folder.
3. Enable GitHub Pages in repo settings.
4. Access at: https://yourusername.github.io/champions-marvel/
